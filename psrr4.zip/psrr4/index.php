<?php

require_once 'app/start.php';


$user = new User();

echo "<br>";

$test = new Test();
$test->abc();

?>