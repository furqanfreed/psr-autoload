<?php

class Test 
{
	public function __construct() 
	{
		echo 'test';
	}


	public function abc() {
		echo "<br>test ex";
	}

}

?>