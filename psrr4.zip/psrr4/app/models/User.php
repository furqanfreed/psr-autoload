<?php

class User 
{
	public function __construct() 
	{
		echo 'Hello.';
	}
}

?>